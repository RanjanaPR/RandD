package com.ranju.CarParking.CarParking;

public class Customer {
	int CarNo=0;
	String Time="00:00:00";
	String OwnerName="unknown";
	int PhoneNo=0;
	int Floor,Section,Compartment;
		/**
			 * @param carNo
			 * @param time
			 * @param name
			 * @param phoneNo
			 */
			public Customer(int carNo, String time, String Ownername, int phoneNo) {
				super();
				CarNo = carNo;
				Time = time;
				OwnerName = Ownername;
				PhoneNo = phoneNo;
			}
			public int getFloor() {
			return Floor;
		}
		public void setFloor(int floor) {
			Floor = floor;
		}
		public int getSection() {
			return Section;
		}
		public void setSection(int section) {
			Section = section;
		}
		public int getCompartment() {
			return Compartment;
		}
		public void setCompartment(int compartment) {
			Compartment = compartment;
		}
			public Customer() {
				int CarNo=0;
				String Time="00:00:00";
				String OwnerName="unknown";
				int PhoneNo=0;

			}
			public int getCarNo() {
				return CarNo;
			}
			public String getTime() {
				return Time;
			}
			
			public String getOwnerName() {
				return OwnerName;
			}
			
			public int getPhoneNo() {
				return PhoneNo;
			}
			
			
			@Override
			public String toString() {
				return "Customer [CarNo=" + CarNo + ", Time=" + Time + ", OwnerName=" + OwnerName + ", PhoneNo="
						+ PhoneNo + "]";
			}
			
}

package com.ranju.CarParking.CarParking;

import java.util.HashMap;
import java.util.Map;
import java.util.SortedSet;
import java.util.TreeMap;
import java.util.TreeSet;

public class ParkingClass 
{
	TreeMap<Integer,Customer> carList=new TreeMap<Integer, Customer>();
	
	SortedSet<Integer> availablePlaces=new TreeSet<Integer>();
	SortedSet<Integer> filledPlaces=new TreeSet<Integer>();
	
	public ParkingClass() {
		for(int index=1;index<161;index++) {
			availablePlaces.add(index);
			
		}
		System.out.println(availablePlaces);
	}
	
	public void AddCar(Customer car) {
		
		if(carList.size()>=160) {
			throw new RuntimeException("index doest exit");
		}
		int key=availablePlaces.first();
		carList.put(key, car);
		availablePlaces.remove(key);
		filledPlaces.add(key);
	}
    public TreeMap<Integer, Customer> retrieveCars() {
        return carList;
 }
 
 public void remoceCar(Customer c) {
        
        if(carList.containsValue(c)) {
               for( Integer index : carList.keySet()) {
                     if(c == carList.get(index))
                     {
                            carList.remove(index);
                            filledPlaces.remove(index);
                            availablePlaces.add(index);
                            return;
                     }
               }
        }
        throw new RuntimeException("Car not found");
 }
 

	
    public static void main( String[] args )
    {
       ParkingClass park=new ParkingClass();
       ParkingClass p = new ParkingClass();
       Customer c1 = new Customer(123456,"01:00:00","Ranjana",123456);
       p.AddCar(c1);
       Customer c2 =new Customer(123457,"02:00:00","Ranju",123457);
       p.AddCar(c2);
       Customer c3 = new Customer(123456,"03:00:00","Bindu",123458);
       p.AddCar(c3);
       System.out.println(p.retrieveCars());
       p.remoceCar(c2);
       System.out.println(p.retrieveCars());
       Customer c4 = new Customer(123456,"04:00:00","Yashu",123459);
       p.AddCar(c4);
       System.out.println(p.retrieveCars());


    	
    	}
    	
    }



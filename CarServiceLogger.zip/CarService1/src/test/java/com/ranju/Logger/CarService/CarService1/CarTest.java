package com.ranju.Logger.CarService.CarService1;

import org.junit.Test;

/**
 * Hello world!
 *
 */
public class CarTest 
{
	@Test
    public void DemonstrateDemo(){
    	CarService carservice= new CarService();
    	carservice.process("BMW");
    }
    {
    	
    	    }
}

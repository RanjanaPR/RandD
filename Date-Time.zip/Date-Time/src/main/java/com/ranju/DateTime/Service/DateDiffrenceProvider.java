package com.ranju.DateTime.Service;

import com.ranju.DateTime.Date_Time.MyDate;
import com.ranju.DateTime.Test.MyDateTestRecord;

public class DateDiffrenceProvider {
		
	private static int FEB=2;
	private static int DAYS_LEAP_YEAR=366;
	private static int DAYS_NON_LEAP_YEAR=365;
	private static int JAN_DAYS=31;
	private static int FEB_DAYS=28;
	private static int MAR_DAYS=31;
	private static int APR_DAYS=30;
	private static int MAY_DAYS=31;
	private static int JUN_DAYS=30;
	private static int JUL_DAYS=31;
	private static int AUG_DAYS=31;
	private static int SEP_DAYS=30;
	private static int OCT_DAYS=31;
	private static int NOV_DAYS=30;
	private static int DEC_DAYS=31;
	public static int[] DAYS_ARRAY= {0,JAN_DAYS,FEB_DAYS,MAR_DAYS,APR_DAYS,MAY_DAYS,JUN_DAYS,JUL_DAYS,AUG_DAYS,SEP_DAYS,
	OCT_DAYS,NOV_DAYS,DEC_DAYS};
	
	

	public static int getDateDiffrence(MyDate startDate,MyDate endDate) {
	
		if(SameDate(startDate, endDate) && Samemonth(startDate, endDate) && SameYear(startDate, endDate)) {
            return 0;
     }
     else if(SameYear(startDate, endDate) && Samemonth(startDate, endDate)) {
            return endDate.getDd() - startDate.getDd();
     }
     else if(SameYear(startDate, endDate) && !Samemonth(startDate, endDate)) {
            return remainigDaysInMonth(startDate)+daysInIntervingMonth(startDate,endDate)+daysInLeadingMonth(endDate);
     }
     else {
            return remianingDaysInYear(startDate)+daysInInterviningYear(startDate,endDate)+daysInLeadingYear(endDate);
     }

		
	}	
		
		private static int daysInLeadingYear(MyDate endDate) {
		
		//	int year=endDate.getYyyy();
		//	IsLeapYear(endDate);
			MyDate startDate=new MyDate(01, 01, endDate.getYyyy());
				
			if(SameYear(startDate, endDate) && Samemonth(startDate, endDate)) {
	            return endDate.getDd() - startDate.getDd();
	     }
	     else {
	            return 1+remainigDaysInMonth(startDate)+daysInIntervingMonth(startDate,endDate)+daysInLeadingMonth(endDate);
	     }
			// return remainigDaysInMonth(startDate)+daysInIntervingMonth(startDate,endDate)+daysInLeadingMonth(endDate)+1;
	}

		private static int daysInLeadingMonth(MyDate endDate) {
		return endDate.getDd();
		 
	}

		private static int daysInInterviningYear(MyDate startDate, MyDate endDate) {
			int NoOfLeapYear=0;
			for(int index=startDate.getYyyy()+1; index<endDate.getYyyy();index++) {
				if(IsLeapYear(index)) {
					NoOfLeapYear++;
				}
			}
	return (((endDate.getYyyy()-startDate.getYyyy()-1)*365)+(1*NoOfLeapYear));
		
	}

		private static int daysInIntervingMonth(MyDate startDate, MyDate endDate) {
			IsLeapYear(startDate.getYyyy());
			int days=0;
	for(int monthIndex=startDate.getMm()+1;monthIndex<endDate.getMm();monthIndex++) {
		
					 days+=DAYS_ARRAY[monthIndex];
	}
	
	return days;

	}

		private static int remianingDaysInYear(MyDate startDate) {
			int year=startDate.getYyyy();
			IsLeapYear(startDate.getYyyy());
			MyDate endDate=new MyDate(31, 12, startDate.getYyyy());
				
			
			if(SameYear(startDate, endDate) && Samemonth(startDate, endDate)) {
	            return endDate.getDd() - startDate.getDd();
	     }
	     else {
	            return remainigDaysInMonth(startDate)+daysInIntervingMonth(startDate,endDate)+daysInLeadingMonth(endDate);
	     }
			// return 1+remainigDaysInMonth(startDate)+daysInIntervingMonth(startDate,endDate)+daysInLeadingMonth(endDate);
		}
	
		private static int remainigDaysInMonth(MyDate startDate) {
			IsLeapYear(startDate.getYyyy());

		return DAYS_ARRAY[startDate.getMm()]-startDate.getDd();
		
		 
	}

		public static boolean SameDate(MyDate startDate,MyDate endDate)  {
			 int date=endDate.getDd()-startDate.getDd();
			 if(date==0) {
			
				 return true;
		}
			return false;
		
			
		}
			public static boolean Samemonth(MyDate startDate,MyDate endDate)  {
				 int month=endDate.getMm()-startDate.getMm();
				 if(month==0) {
				
					 return true;
			}
				return false;
				
			}	
			public static boolean SameYear(MyDate startDate,MyDate endDate)  {
				 int month=endDate.getYyyy()-startDate.getYyyy();
				 if(month==0) {
					 return true;
				
			}
				 return false;
				
			}	
			private static boolean IsLeapYear(int  year) {
	//			int year=startDate.getYyyy();
				if((year % 4==0 && year%100!=0 )||(year%400==0)) {
					DAYS_ARRAY[2]=29;		
				return true;
						
					}
				DAYS_ARRAY[2]=28;
				return false;
				
								 
			}

	}
	





















/*int Month=(endDate.getMm()-startDate.getMm());
int  ExpectedResult=Month*30+(endDate.getDd()-startDate.getDd());
return ExpectedResult;
*/


/*int ExpectedResult = endDate.getDd()-startDate.getDd();
if()
return ExpectedResult;*/

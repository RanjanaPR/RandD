package com.lambda.client;

import java.util.ArrayList;
import java.util.List;

import com.lambda.demo.MyInterface;
import com.lambda.model.MyClass;
import com.lambda.model.Student;

public class ClientTest {

	public static void main(String[] args) {
		// TODO Auto-generated method stub
		MyInterface myInterface=new MyClass();
		List<Student> stuList=new ArrayList<>();
		stuList.add(new Student("Bindu", 22));
		stuList.add(new Student("Yashu", 23));
		stuList.add(new Student("Ranju", 22));
		
		List<Student> sortStudents=myInterface.sortStudents(stuList);
		for(Student student:sortStudents) {
			System.out.println(student.getName()+"\t"+student.getAge());
		}
		
		myInterface.sortStudents(stuList);
		
		MyInterface.greet("Bindu");
		
		List<Integer> intList=new ArrayList<>();
		intList.add(1000);
		intList.add(50);
		intList.add(9000);
		intList.add(100);
		Integer maxNum=myInterface.getMaxNum(intList);
		System.out.println("Max:"+maxNum);
		
		

	}

}

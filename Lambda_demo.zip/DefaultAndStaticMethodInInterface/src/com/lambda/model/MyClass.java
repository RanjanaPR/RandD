package com.lambda.model;

import java.util.Collections;
import java.util.List;

import com.lambda.demo.MyInterface;

public class MyClass  implements MyInterface{
	@Override
	public Integer getMaxNum(List<Integer> intList) {
		Integer maxNum=Collections.max(intList);
		return maxNum;
	}
	

}

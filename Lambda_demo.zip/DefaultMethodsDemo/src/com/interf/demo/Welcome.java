package com.interf.demo;

public class Welcome implements I1,I2{

	@Override
	public void display() {
		
		
			//I1.super.display();
			I2.super.display();
		}
	

public static void main(String[] args) {
	Welcome welcome=new Welcome();
	welcome.display();
}
}

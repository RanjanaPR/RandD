package com.demo.client;

import java.util.ArrayList;
import java.util.List;
import java.util.function.Consumer;

import com.demo.Student;

public class ClientTest {

	public static void main(String[] args) {
		List<Student> stuList=new ArrayList<>();
		stuList.add(new Student("Bindu",22));
		stuList.add(new Student("Yashu",23));
		stuList.add(new Student("Ranju",21));
		
		stuList.forEach(System.out::println);
		
		for(Student student:stuList) {
			System.out.println(student);
		}
		

	}

}
class MyConsumer implements Consumer<Student>
{

	@Override
	public void accept(Student student) {
		System.out.println(student);
		
	}
	
}

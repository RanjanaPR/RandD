package com.ranju.MakeMyTrip.Make_My_Trip;

public class Flights {
	public static void main( String[] args ){
		TripList flight=new TripList();
		flight.addFlights(new TripPojo("Indigo",12,17,50000,"bangalore","manglore",2));
		flight.addFlights(new TripPojo("jetAirways",9,2,8050,"mangalore","chennai",3));
		flight.addFlights(new TripPojo("kingFisher",17,18,35000,"bangalore","goa",8));
				flight.addFlights(new TripPojo("emirates",8,13,5000,"delhi","dubai",4));
		
		for(TripPojo trip:flight.getAllFlightDetails()){
			System.out.println(trip);
		}
		
System.out.println("=======================================================");
		
		System.out.println(flight.getByFlightNo(3));
		
		System.out.println("=======================================================");
		
		/*for(TripPojo trip:flight.removeFlightDetails(1)){
			System.out.println(trip);
		}*/
		for(TripPojo trip:flight.updateFlightDetails(1, 11, 9)){
			System.out.println(trip);
		}
		
		System.out.println("=======================================================");
		for(TripPojo trip:flight.updateFlightDestination(2, "delhi")){
			System.out.println(trip);
		}
		
		System.out.println("=======================================================");
		for(TripPojo trip:flight.sortFlightByPrice("bangalore", "chennai")){
			System.out.println(trip);
		}
		
		System.out.println("=======================================================");
		for(TripPojo trip:flight.sortFlightByTime("bangalore", "chennai")){
			System.out.println(trip);
		}

		System.out.println("=======================================================");
		for(TripPojo trip:flight.morningFlight("bangalore", "chennai")){
			System.out.println(trip);
		}
	}
}


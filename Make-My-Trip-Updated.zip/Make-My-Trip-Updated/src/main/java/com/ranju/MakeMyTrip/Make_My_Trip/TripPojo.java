package com.ranju.MakeMyTrip.Make_My_Trip;

public class TripPojo {
	int flightNo;
	String AirLinesNameName;
	int ArrivalTime;
	int DepartureTime;
	int cost;
	String DepartureCity;
	String ArrivalCity;
	int TravelTime;
	static int autoflightNo;

	public TripPojo( String AirLinesNameName, int arrivalTime,
			int departureTime, int cost, String DepartureCity, String ArrivalCity,
			int TravelTime) {
		super();
		
		this.AirLinesNameName = AirLinesNameName;
		this.ArrivalTime = arrivalTime;
		this.DepartureTime = departureTime;
		this.cost = cost;
		this.DepartureCity = DepartureCity;
		this.ArrivalCity = ArrivalCity;
		this.TravelTime = TravelTime;
	}
	{
		flightNo=++autoflightNo;
	}

	public int getFlightNo() {
		return flightNo;
	}



	public String getAirLinesNameName() {
		return AirLinesNameName;
	}

	public void setAirLinesNameName(String AirLinesNameName) {
		this.AirLinesNameName = AirLinesNameName;
	}

	public int getArrivalTime() {
		return ArrivalTime;
	}

	public void setArrivalTime(int arrivalTime) {
		ArrivalTime = arrivalTime;
	}

	public int getDepartureTime() {
		return DepartureTime;
	}

	public void setDepartureTime(int departureTime) {
		DepartureTime = departureTime;
	}

	public int getCost() {
		return cost;
	}

	public void setCost(int cost) {
		this.cost = cost;
	}

	public String getDepartureCity() {
		return DepartureCity;
	}

	public void setDepartureCity(String DepartureCity) {
		this.DepartureCity = DepartureCity;
	}

	public String getArrivalCity() {
		return ArrivalCity;
	}

	public void setArrivalCity(String ArrivalCity) {
		ArrivalCity = ArrivalCity;
	}

	public int getTravelTime() {
		return TravelTime;
	}

	public void setTravelTime(int TravelTime) {
		this.TravelTime = TravelTime;
	}

	public static int getAutoflightNo() {
		return autoflightNo;
	}

	@Override
	public String toString() {
		return "TripPojo [flightNo=" + flightNo + ", AirLinesNameName=" + AirLinesNameName
				+ ", ArrivalTime=" + ArrivalTime + ", DepartureTime="
				+ DepartureTime + ", cost=" + cost + ", DepartureCity=" + DepartureCity
				+ ", ArrivalCity=" + ArrivalCity + ", TravelTime=" + TravelTime + "]";
	}

}
